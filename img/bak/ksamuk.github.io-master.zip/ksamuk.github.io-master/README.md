My personal website made using Hyde: http://hyde.getpoole.com
