---
layout: page
title: Publications
---

<a href="http://scholar.google.ca/citations?user=6SUFQxQAAAAJ&hl=en">My Google Scholar page</a>

* <b>Samuk, K.</b> 2016. Perspective: Inversions and the origin of behavioral differences in cod. Molecular Ecology, In Press.

* Miller, S.E., <b>Samuk, K.</b>, and Rennison, D. 2016. An experimental test of predation’s effect upon behaviour and trait correlations in threespine stickleback. Biological Journal of the Linnean Society, In Press.

* <b>Samuk, K.</b>, Iritani, D. and Schluter, D. 2014. Reversed brain size sexual dimorphism accompanies loss of parental care in white sticklebacks. Ecology and Evolution. doi: 10.1002/ece3.1175. <a href="/pdf/Samuk%20et%20al.%202014%20-%20Ecol%20Evo.pdf">PDF</a>.

* <b>Samuk, K.</b> and Avilés, L. 2013. Indiscriminate care of offspring predates the evolution of sociality in alloparenting social spiders. Behavioral Ecology and Sociobiology 67(8): 1275-1284.<a href="/pdf/Samuk%20%26%20Aviles%202013%20-%20BEAS.pdf">PDF</a>.

* <b>Samuk, K.</b>, LeDue, E.E., and Avilés, L. 2011. Sister clade comparisons reveal reduced maternal care behavior in social cobweb spiders (Anelosimus spp.). Behavioral Ecology 23(1):35-43. <a href="/pdf/Samuk%20et%20al.%202011%20-%20Behav%20Ecol.pdf">PDF</a>.
