---
layout: page
title: Research
---

My research is focused on understanding the genetics of adaptation and speciation. My collaborators and I use a variety of approaches to study these processes, including experiments, quantitative genetics, population genomics and meta-analyses.

## 1. Recombination and evolution

Meiotic recombination is common in most diploid organisms. This process involves the mixture of alleles between chromosomes prior to production of a gamete. This results in the offspring of an organism recieving a unique "remixed" version of their parent's genotype. I am currently working on understanding how recombination shapes evolutionary processes, and how recombination itself evolves.

### Does recombination rate influence where adaptation occurs in the genome?

![Global stickleback divergence pairs](/images/sticklemap.png)
<div class="message">Sticklebacks have diverged in many different ecogeographic contexts.</div>

The genetic architecture of adaptation is thought to be a result of the interplay between natural selection, gene flow and the structure of the genome. One example of this is the localization of adaptive alleles in regions of low recombination, particularly when adaptation occurs in the face of gene flow. To test this idea, my colleagues and I created a large dataset of genomic data from pairs of stickleback populations from around the world that vary in the presence of gene flow and divergent selection.

### Is recombination rate itself optimized by natural selection?

Theory predicts that more frequent recombination is favorable when the direction of selection flutates (e.g. seasonally). This implies that recombination rate may itself be the target of optimizing selection. Given that there is a great deal of heritable variation for genome-wide recombination rate in plant and animal populations, we are investigating whether natural populations display signatures of local adaptation for recombination rate.

### Does natural selection shape the recombinational landscape of the genome?

Under certain circumstances, theory predicts that natural selection can favor the reduction of recombination at specific locations in the genome. This can, for example, involve the evolution of a chromosomal inversion. I am working on putting modern transgenic technologies to work answering this question.

## 2. The genomics of speciation

What are the genetic changes that result in the formation of new species? How important is natural selection in this process? I am applying a combination of genomic and traditional evolutionary tools to study these questions in a very young species: the white stickleback.

### White sticklebacks

![White and common stickleback](/images/wc_hand.jpg)
<div class="message"> Male white (top) and common (bottom) threespined sticklebacks. </div>

White sticklebacks are a type of marine threespined stickleback found exclusively in Nova Scotia, Canada. They are often found alongside "common" marine threespined sticklebacks, from which they are distinguished in several ways, notably white (instead of blue) nuptial colour of males and a complete lack of parental care.

As part of my PhD research, I answered three questions about these unique fish:

1. Are white and common sticklebacks reproductively isolated?
2. What genetic changes underlie this isolation?
3. What are the phenotypic effects of these changes?

## 3. The evolution of the brain 

<iframe src='https://gfycat.com/ifr/UnknownAggravatingAfricanjacana' frameborder='0' scrolling='no' width='640' height='367.81609195402297' allowfullscreen></iframe>
<script async src="//cdn.embedly.com/widgets/platform.js" charset="UTF-8"></script>
<div class="message"> A CT scan from my work on the neuromorphological correlates of predation.</div>

The brain has received comparatively little attention from evolutionary biologists. I am working on collecting natural historical data about variation in the brain and testing hypotheses about the evolution and genetics of brain structure using threespined sticklebacks.

Work so far has included:

1. What are the neuromorphological correlates of parental care in sticklebacks? 
2. How does the brain evolve in response to predators? (an experimental study with Diana Rennison) 
3. What is the nature of sexual dimorphism in the stickleback brain?

